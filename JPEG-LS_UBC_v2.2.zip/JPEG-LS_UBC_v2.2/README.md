# UBC JPEG-LS encoder/decoder

This software maybe the earliest code implementation of JPEG-LS, which is from University of British Columbia (UBC): http://www.stat.columbia.edu/~jakulin/jpeg-ls/mirror.htm (v2.2). The website appears to be inactive after 2024. Fortunately, I downloaded it before 2024, and fixed some bugs that caused compilation failures. **Note**: if you use this code, please still indicate the link from UBC.

This software is written in C:

- **JPEGLSenc** can encode a PGM image file (.pgm) to a JPEG-LS image file (.jls);
- **JPEGLSdec** can decode a JPEG-LS image file (.jls) to a PGM image file (.pgm).

　

## To compile

To compile the software, make sure you have the GCC compiler ([MinGW](https://www.mingw-w64.org/)) installed on your Windows. Then open a CMD command line in this directory, and run the following commands:

```
gcc -DBIG_ENDIAN -DPGMPREFIX=\"loco\" -DMELCODE -DEXTERNDISTRIB -Dinline="" -DNDEBUG -lm -o JPEGLSdec.exe JPEGLSdec/*.c
gcc -DBIG_ENDIAN -DPGMPREFIX=\"loco\" -DMELCODE -DEXTERNDISTRIB -Dinline="" -DNDEBUG -lm -o JPEGLSenc.exe JPEGLSenc/*.c
```

The first command will compile the decoder, outputting **JPEGLSdec.exe**.

The second command will compile the encoder, outputting **JPEGLSenc.exe**.

　

## To encode

Run the following command in CMD to encode:

```
JPEGLSenc.exe  <input_file_name.pgm>  -o<output_file_name.jls>
```

Where the input file can be 8-bit or 16-bit grayscale PGM image file. For example:

```
JPEGLSenc.exe example_8bit.pgm -oexample_8bit.jls
```

Which will outputs example_8bit.jls

　

## To decode

Run the following command in CMD to encode:

```
JPEGLSdec.exe  <input_file_name.jls>  -o<output_file_name.pgm>
```

Where the input file can be 8-bit or 16-bit grayscale JLS image file. For example:

```
JPEGLSdec.exe example_8bit.jls -oexample_8bit_out.pgm
```

Which will outputs example_8bit_out.pgm

　

If `<input_file_name.jls>` is a 24-bit RGB JLS image, don't use `-o`, just run following command:

```
JPEGLSdec.exe example_rgb24bit.jls
```

This command will outputs three `.out` files, rename them to `.pgm`, you will find that they are actually the red, green and blue channels of the original 24-bit JLS file.
